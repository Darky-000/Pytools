"""Ascii module provided by pytools, this module helps to do anything in command line interface.
such like, drawing image, colors, tables, file tree, ascii animation etc"""
import subprocess as sp
import os
import pyfiglet, re
import random

class Colors:
	"""This is a class Colors for coloring text wonderfully"""
	def __init__(self):
		self.reset = "\033[0m"
		self.colors = {
			"RED": (255, 20, 10),
			"GREEN": (20, 255, 10),
			"BLUE": (10, 20, 255),
			"CYAN": (10, 155, 255),
			"WHITE": (255, 255, 255),
			"BLACK": (0, 0, 0),
			"DARK_GRAY": (100, 100, 100),
			"LIGHT_GRAY": (190, 190, 190),
			"PINK": (255, 150, 255),
			"BROWN": (120, 60, 0),
			"YELLOW": (255, 255, 10),
			"ORANGE": (255, 100, 10),
			"PURPLE": (255, 50, 255)
		}
		self.all_colors_names = []
	
	def RGB(self, rgb, bg=False, bold=False):
		"""Returns ansi escape color code
		
		rgb(type: tuple) -> the rgb value of any color 0-255
		
		bg(default: False) -> If true, the text have a colored background too
		
		bold(default: False) -> If true, the text have bolded effect"""
		r, g, b = [max(0, min(255, int(x))) for x in rgb]
		mode = 48 if bg else 38
		bold_code = "1;" if bold else ""
		return f"\033[{bold_code}{mode};2;{r};{g};{b}m"
	
	def init(self):
		"""Initializes all color variables"""
		for name, (r, g, b) in self.colors.items():
			setattr(self, name, self.RGB((r, g, b)))
			setattr(self, f"l{name}", self.RGB((r, g, b), bold=True))
			setattr(self, f"BG_{name}", self.RGB((r, g, b), bg=True))
			setattr(self, f"BG_l{name}", self.RGB((r, g, b), bg=True, bold=True))
			self.all_colors_names.extend([name, f"l{name}", f"BG_{name}", f"BG_l{name}"])
	
	def print(self, *text, sep=" ", end="\n", flush=False, autoreset=True, color=None):
		"""Prints a colored or none colored text
		
		*text -> The text to print
		sep(default:" ") -> Text separator like builtins.print function have
		end(default:"\n") -> end argument like builtins.print function have
		flush(default:False) -> flush argument like builtins.print have
		autoreset(default: True) -> If True, it will automatically clear the color
		color(default:None) -> If any ansi escape code provided it will append it will use this to color your text"""
		text = sep.join(text)
		
		if color is None:
			print(text, flush=flush, end=end)
		elif (color.startswith("\033") or color.startswith("\1xb")) and color.endswith("m"):
			print(color+text+self.reset if autoreset else color+text, flush=flush, end=end)
		else:
			raise ValueError("Unknown color %s"%color)
		
def clear(ansi=True):
	"""Clears the screen
	
	ansi(default:True) -> If True, it will clear the screen instantly but still you may see some junks"""
	if ansi:
		print("\033[2J\033[H", end="", flush=True)
	else:
		os.system('clear')

class Beautifulizer:
	def __init__(self):
		"""For pretty formatting texts and better text handling"""
		self._color = Colors()
		self._color.init()
	
	def format_code(self, code, lang="python"):
		"""Pretty format any programming language code"""
		lang = lang.upper()
		max_line_length = 0
		for line in code.splitlines():
			max_line_length = max(max_line_length, len(line)+3)
		formatted_code = []
		formatted_code.append(f"{self._color.lCYAN}{lang}\n{self._color.DARK_GRAY}{'—'*max_line_length}{self._color.reset}")
		for line in code.splitlines():
			formatted_code.append(f"{self._color.GREEN}{line}{self._color.reset}")
		formatted_code = f"{'\n'.join(formatted_code)}\n"
		return formatted_code
	
	def format_banner(self, text, font="standard"):
		"""Format a banner"""
		return pyfiglet.figlet_format(text, font)
	
	def format_bold(self, text):
		"""Format bold header"""
		return f"{self._color.lWHITE}{text}{self._color.reset}"
	
	def pretty(self, text):
		"""Pretty format your entire provided text with some special syntaxs
		
		1. **text** (Bold text)
		2. ---[text]--- (banner)
		3. ```text``` (python code)
		4. %clear% (clears the screen)
		5. OS(text) (runs the command)"""
		bold_pattern = r"\*\*(.*?)\*\*"
		figlet_pattern = r"---\[(.*?)\]---"
		code_pattern = r"```(.*?)```"
		clear_screen = "%clear%"
		cmd_execute_pattern = r"OS\((.*?)\)"
		
		def banner_replacer(match):
			content = match.group(1)
			parts = content.split(",,")
			text = parts[0].strip()
			font = parts[1].strip() if len(parts) > 1 else "standard"
			return self.format_banner(text, font)
		
		text = re.sub(figlet_pattern, banner_replacer, text, flags=re.DOTALL)
		
		def python_code_replacer(match):
			content = match.group(1)
			return self.format_code(content)
		
		text = re.sub(code_pattern, python_code_replacer, text, flags=re.DOTALL)
		
		def bold_replacer(match):
			content = match.group(1)
			return self.format_bold(content)
		
		text = re.sub(bold_pattern, bold_replacer, text, flags=re.DOTALL)
		
		def cmd_replacer(match):
			cmd = match.group(1)
			response = sp.run(
				cmd.split(),
				capture_output=True,
				text=True
			)
			if not response.stderr:
				return response.stdout
			return response.stderr
		
		text = re.sub(cmd_execute_pattern, cmd_replacer, text, flags=re.DOTALL)
		
		if clear_screen in text:
			clear(ansi=False)
			text = text.replace(clear_screen, "")
		
		return text

