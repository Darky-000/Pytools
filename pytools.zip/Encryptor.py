"""The module Encryptor provided by pytools, support encryption and decryption with a kind of sha256 one way hash supporting custom chars and password!"""

import base64
import random

class UltimateDecryption:
	"""The main motive of this class is to decrypt a text by brute forcing every encryptions, but also supports encode and decoding feature"""
	def __init__(self):
		self._methods = {
			"a85encode":base64.a85encode,
			"b16encode":base64.b16encode,
			"b32encode":base64.b32encode,
			"b32hexencode":base64.b32hexencode,
			"b64encode":base64.b64encode,
			"b85encode":base64.b85encode,
			"z85encode":base64.z85encode,
			"a85decode":base64.a85decode,
			"b16decode":base64.b16decode,
			"b32decode":base64.b32decode,
			"b32hexdecode":base64.b32hexdecode,
			"b64decode":base64.b64decode,
			"b85decode":base64.b85decode,
			"z85decode":base64.z85decode
		}
	
	def encode(self, text, method="b64encode"):
		"""Encodes the text using provided method
		
		text -> Text to encode
		method(default:"b64encode") -> Method to encode"""
		if not isinstance(text, bytes):
			text = text.encode("utf-8")
		
		if not method in self._methods:
			raise ValueError(f"Unknown method {method}")
		
		if not method.endswith("encode"):
			raise ValueError("Invalid method for function encode!")
		return self._methods[method](text)
	
	def decode(self, encoded, method="b64decode"):
		"""Decodes the encoded using provided method
		
			encoded -> encoded text to decode
			method(default:"b64decode") -> Method to decode"""	
		if not method in self._methods:
			raise ValueError(f"Unknown method {method}")
		
		if not method.endswith("decode"):
			raise ValueError("Invalid method for function decode!")
		return self._methods[method](encoded)
	
	def decode_all(self, encoded, methods=[]):
		"""Decodes the encoded text using provided methods
		
		encoded -> Encoded text to decode
		methods(default:All methods) -> Try to brute force on these methods"""
		if not methods:
			methods = [i for i in self._methods if i.endswith("decode")]
		output = {}
		for method in methods:
			try:
				output[method] = self.decrypt(encoded, method)
			except ValueError:
				continue
		return output

class Hash:
	"""Provides one-way custom hashing algorithm by pytools devloper"""
	def __init__(self):
		self.algorithms = ["bat"]
	
	def bat(self, text, pwd="1", chars="abhts0123456789", length=64):
		"""Bat is a low level hashing algorithm, pretty good for learning and custom projects. may not great for industrial security"""
		seed = f"{pwd}%{text}%{chars}%{length*length}"
		random.seed(seed)
		encoded = "bat-"
		while not len(encoded) == length:
			char = random.choice(chars)
			encoded+=char
		random.seed() # Reset seed
		return encoded