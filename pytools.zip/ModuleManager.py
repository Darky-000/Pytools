"""ModuleManager is a module that helps to manage modules, such like installing and uninstalling modules, list of all installed modules and more useful features for begginers."""

from collections.abc import Iterable
from importlib import metadata
import importlib.util
import sys
import subprocess as sp

__all__ = [
	"ModuleManagerError",
	"InvalidModuleName",
	"PIPExecutionError",
	"modules_list",
	"module_exists",
	"get_module_version",
	"install",
	"uninstall",
]


# ----- Exceptions -----
class ModuleManagerError(Exception):
	"""Base exception for ModuleManager."""


class InvalidModuleName(ModuleManagerError):
	"""Raised when module name or module collection is invalid."""


class PIPExecutionError(ModuleManagerError):
	"""Raised when a pip command fails."""


# ----- Internal Helpers -----
def _normalize_names(names):
	"""
	Convert module input into a clean list of names.

	Accepted values:
	- "requests"
	- "requests numpy"
	- ["requests", "numpy"]
	- ("requests", "numpy")
	- any other iterable of strings
	"""

	if isinstance(names, str):
		names = names.split()

	elif isinstance(names, Iterable) and not isinstance(names, (bytes, bytearray, dict)):
		names = list(names)

	else:
		raise InvalidModuleName(
			f"{type(names).__name__} object cannot be interpreted as a string or iterable of strings."
		)

	cleaned = []
	for name in names:
		if not isinstance(name, str):
			raise InvalidModuleName(
				f"{type(name).__name__} object cannot be interpreted as a string module name."
			)

		name = name.strip()
		if name:
			cleaned.append(name)

	return cleaned


def _module_exists(name):
	"""
	Check whether a module or distribution exists.
	Tries import name first, then package metadata name.
	"""

	try:
		if importlib.util.find_spec(name) is not None:
			return True
	except (ImportError, ValueError, TypeError):
		pass

	try:
		metadata.version(name)
		return True
	except metadata.PackageNotFoundError:
		return False
	except Exception:
		return False


def _modules_exists(module_names):
	"""
	Internal module existence checker.
	Always returns a dictionary.
	"""

	module_names = _normalize_names(module_names)

	return {
		name: _module_exists(name)
		for name in module_names
	}


def _run_pip_command(args):
	"""
	Run a pip command safely.
	"""

	cmd = [sys.executable, "-m", "pip", *args]

	try:
		results = sp.run(
			cmd,
			capture_output=True,
			text=True,
			timeout=300
		)

	except sp.TimeoutExpired as exc:
		raise PIPExecutionError(
			f"pip command timed out after 300 seconds: {' '.join(cmd)}"
		) from exc

	except OSError as exc:
		raise PIPExecutionError(
			f"Failed to execute pip command: {exc}"
		) from exc

	if results.returncode != 0:
		message = (results.stderr or results.stdout or "pip command failed").strip()
		raise PIPExecutionError(message)

	return results


# ----- Features -----
def modules_list(version=False):
	"""
	Return all installed modules.

	Returns:
	- list of module names when version=False
	- list of 'name==version' strings when version=True
	"""

	modules = []
	seen = set()

	for pkg in metadata.distributions():
		name = pkg.metadata.get("Name") or pkg.name

		if not name or name in seen:
			continue

		seen.add(name)
		modules.append(f"{name}=={pkg.version}" if version else name)

	return modules


def module_exists(module_names):
	"""
	Check whether one module or many modules are installed.

	Returns:
	- bool for a single module
	- dict for multiple modules
	"""

	results = _modules_exists(module_names)

	if not results:
		return {}

	if len(results) == 1:
		return next(iter(results.values()))

	return results


def get_module_version(module_name):
	"""Get a particular module's version."""
	try:
		return metadata.version(module_name)
	except metadata.PackageNotFoundError:
		return None


def install(module_names, upgrade=False):
	"""
	Install or upgrade modules safely.
	"""

	module_names = _normalize_names(module_names)

	if not module_names:
		return False

	exists_map = _modules_exists(module_names)

	modules_to_install = [
		name
		for name in module_names
		if upgrade or not exists_map[name]
	]

	if not modules_to_install:
		return True

	args = ["install"]

	if upgrade:
		args.append("--upgrade")

	args.extend(modules_to_install)

	_run_pip_command(args)

	post_check = _modules_exists(modules_to_install)
	return all(post_check.values())


def uninstall(module_names):
	"""
	Uninstall provided modules safely.
	"""

	module_names = _normalize_names(module_names)

	if not module_names:
		return False

	exists_map = _modules_exists(module_names)

	modules_to_uninstall = [
		name
		for name in module_names
		if exists_map[name]
	]

	if not modules_to_uninstall:
		return False

	_run_pip_command(["uninstall", "-y", *modules_to_uninstall])

	post_check = _modules_exists(modules_to_uninstall)
	return not any(post_check.values())

