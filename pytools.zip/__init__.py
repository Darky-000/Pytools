"""Pytools - Python tools to make programming easier (For Linux)
Created by Rocky The Programmer
For technical issues or Update ideas, contact in...
Gmail: rockyprogrammer000@gmail.com

Note: This module is in development, you can still use it but may face some issues"""

# Module may feel messy, but I'am trying my best to make it easier to understand and use
import functools
import os, sys

__version__="1.4"
modules = ["Ascii", "Encryptor", "FileManager", "Json", "ModuleManager"]

PLUGIN_PATH = os.path.join(os.path.dirname(__file__), "plugin")
if os.path.exists(PLUGIN_PATH):
	for file in os.listdir(PLUGIN_PATH):
		file, ext = file.split(".")
		if ext == "py":
			exec(f"from pytools.plugin import {file}")

def load_plugin(path):
	"""Loads plugin external plugins in pytools like game, you just need to call the function and provide him the plugin file path (plugin must be a python single file under 100MB)"""
	fm = FileManager.Open(path)
	CORE_PATH = os.path.dirname(__file__)
	if fm.size() > 104857600:
		raise FileManager.FileManagerError(f"{fm.filename()} was too big, max 100mb")
	if fm.extension() != ".py":
		raise FileManager.FileManagerError(f"Invalid file format {fm.extension()}")
	if fm.filename() in os.listdir(CORE_PATH) or fm.filename() in os.listdir(PLUGIN_PATH):
		raise FileManager.FileManagerError(f"{fm.filename()} was already in pytools, no name duplication was possible!")
	fm.copy(PLUGIN_PATH)
	print(f"New plugin added successfully, reload your programme and try to run \nfrom pytools import {fm.filename().split('.')[0]}")

def plugin_list():
	"""returns all active plug-in's in list-datatype"""
	plugins = []
	for file in os.listdir(PLUGIN_PATH):
		plugins.append(file.split(".")[0])
	return plugins

def ErrorFix(func):
	"""Handles errors, without raising a error in the programme. The programme will still can be running (If it's ctrl+c or ctrl+d the programme will stop without raising any error, but if it's anything else it will return a Exception object. DON'T USE THIS DECORATOR IF YOUR PROJECT IS BIG AND REQUIRES MORE SECURITY)"""
	@functools.wraps(func)
	def wrapper(*args, **kwargs):	
		try:
			return func(*args, **kwargs)
		except (KeyboardInterrupt, EOFError):
			sys.exit()
		except Exception as e:
			return e
	return wrapper

def clean(object, identity="temp_", restricted=None):
	"""Deletes temporary variables, functions and classes from the class object
	
	object -> Class object
	
	identify(default:'temp_') -> If variable, function or class startswith identify, then it will be removed
	
	restricted: list(default:None) -> if restricted names are provided, the restricted variables will not delete"""
	cleared = []
	for i in dir(object):
		if i.startswith(identity):
			if restricted is not None and i in restricted:
				continue
			exec(f"del {object}.{i}")
			cleared.append(f"{type(object).__name__}.{i}")
	return cleared

