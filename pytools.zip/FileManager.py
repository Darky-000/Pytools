"""FileManager module provided by pytools to manage and monitor files"""

import hashlib
from pathlib import Path
import os, sys
import shutil

class FileManagerError(Exception):
	"""Raised when any FileManager File have some issues!"""

class Open:
	"""opens the provided file and gaves information about it!"""
	def __init__(self, path):
		self.path = Path(path)
	
	def _validate_mode(self, mode, allowed):
		if mode not in allowed:
			raise ValueError(f"Expected mode from {allowed}, got {mode!r}")
	
	def read(self, mode="r",lines=False):
		"""Returns file data
		
		mode(default:"r") -> file read modes, available modes are r, rb
		lines(default:False) -> if True, returns file lines"""
		self._validate_mode(mode, ("r", "rb"))
		with open(self.path, mode) as f:
			return f.readlines() if lines else f.read()
		
	def write(self, data=None, mode="w"):
		"""Writes data to file
		
		data(default:None) -> data to store in file, if None it will create a empty file
		mode(default:"w") -> file write modes, available modes w, wb"""
		self._validate_mode(mode, ("w", "wb"))
		if data is None:
			data = b"" if "b" in mode else ""
		with open(self.path, mode) as f:
			f.write(data)
	
	def clear_data(self):
		"""Clears all file data"""
		self.write("")
	
	def delete(self):
		"""Deletes the file (caution: May cause to lose important data⚠)"""
		self.path.unlink(missing_ok=True)
	
	def size(self):
		"""returns file size in bytes"""
		return self.path.stat().st_size
	
	def hash(self):
		"""returns file hash in sha256"""
		data = self.read(mode="rb")
		return hashlib.sha256(data).hexdigest()
	
	def filename(self):
		"""Returns file name"""
		return self.path.name
	
	def extension(self):
		"""Returns file extension"""
		return self.filename.split(".")[-1]
	
	def absolute(self):
		"""Returns absolute file path"""
		return str(self.path.resolve())
	
	def copy(self, destination):
		"""Copy the file"""
		shutil.copy2(str(self.path), str(destination))
	
	def move(self, destination):
		"""Move file to another path"""
		path = shutil.move(str(self.path), str(destination))
		self.path = Path(path)
	
	def rename(self, new_name):
		"""Rename the file"""
		new_path = self.path.with_name(new_name)
		self.path.rename(new_path)
		self.path = new_path
	
	def get_mtime(self):
		"""Get file modification time"""
		return os.path.getmtime(str(self.path))
	
	def __repr__(self):
		return f"Open({str(self.path)!r})"
	
	def __str__(self):
		return str(self.path)
	
	def __len__(self):
		if not self.path.exists():
			return 0

		return self.size()

