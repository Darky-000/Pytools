"""
This is the Json module provided by Package pytools.
The module Json provides much more features than pythons built-in module json and new features will be added later.
Since, the module Json is in development you may face some issues but, i'am trying my best to avoid critical errors.

If you may face some critical issues, new update ideas and wanted to talk with me, you can contact on...

Gmail: rockyprogrammer000@gmail.com
"""
import json, os, time

__all__ = [
	"InvalidJsonError",
	"JsonFileNotFoundError",
	"InvalidJsonFileError",
	"load",
	"write_json",
	"ValidJson"
]

# ----- Exceptions -----
class InvalidJsonError(Exception):
	"""Raised when json is Invalid!"""

class JsonFileNotFoundError(Exception):
	"""Raised when json file not found!"""

class InvalidJsonFileError(Exception):
	"""Raised when provided json file was empty or invalid!"""

class CacheFileNotFoundError(Exception):
	"""Raised when cache file not found!"""

# ----- Internal Helpers -----
_cache = []

def _valid_json(filepath, strict=False):
	if not strict:
		return filepath.endswith(".json") and os.path.isfile(filepath)
	try:
		with open(filepath, "r") as f:
			json.load(f)
		return True
	except (FileNotFoundError, PermissionError, json.decoder.JSONDecodeError):
		return False

def _save_to_cache(filepath, data, mtime):
	if _cache:
		for file in _cache:
			if file.get("filepath") == filepath and file.get("mtime") == mtime:
				return False # File does not saved to cache, because it's already there
	_cache.append({"filepath":filepath, "data": data, "mtime": mtime})
	return True

def _load_from_cache(filepath, mtime):
	if _cache:
		for file in _cache:
			if file.get("filepath") == filepath and mtime == file.get("mtime"):
				return file.get("data") # Return file data if file cache found!
	return None

def _load_latest_stored_cache():
	if _cache:
		latest = _cache[-1]
		filepath = latest.get("filepath")
		mtime = latest.get("mtime")
		return _load_from_cache(filepath, mtime)
	return None
	

# ----- Public features -----
def load(filepath, name_safe=True):
	"""Loads Json file by using filepath, if filepath does not exists raises JsonFileNotFoundError else returns dict.
	
	name_safe: If true, fixes the json file name if it does not endswith .json (JavaScript Object Notation or JSON file extension)"""
	if not filepath.endswith(".json") and name_safe:
		filepath += ".json"
	
	if not os.path.isfile(filepath):
		raise JsonFileNotFoundError(f"{filepath} not found!")
	
	if not _valid_json(filepath, strict=True):
		raise InvalidJsonFileError(f"{filepath} was invalid or empty!")
	
	mtime = os.path.getmtime(filepath)
	cache_result = _load_from_cache(filepath, mtime)
	if cache_result is not None:
		return cache_result
	
	try:
		with open(filepath, "r") as f:
			data = json.load(f)
	except UnicodeDecodeError:
		with open(filepath, "rb") as f:
			data = json.load(f)
	
	_save_to_cache(filepath, data, mtime)
	return data

def write_json(filepath, data=None, pretty=True, safe=True):
	"""
	function write_json writes a json file with safety
	
       Parameters
	|
	|
	|filepath : json file path, where the json data will be written.
	|data     : json data, if None the will have a empty dict (default: None)
	|pretty   : Manages how the json data will be written on file, if True the Json file will be easy to read (default: True)
	|safe     : Ensures that folders exists, if not it will be created automatically (default: True)
	"""
	dirs = os.path.dirname(filepath)
	
	if dirs and safe: # Create all required dirs if safe = True and if any dir mentioned in filepath
		os.makedirs(dirs, exist_ok=True)
	
	if data is None: # If data is not provided handles it
		data = {}
	
	with open(filepath, "w") as f:
		if pretty:
			json.dump(data, f, indent=4)
		else:
			json.dump(data, f)
	mtime = os.path.getmtime(filepath)
	_save_to_cache(filepath, data, mtime)

def ValidJson(filepath, strict=False):
	"""Validates that a json file is valid or not (strict=True may work slower and memory consuming)"""
	
	return _valid_json(filepath, strict=strict)

def get(path, default=None, sep="."):
	"""Get key from latest stored cache file, (default for fallback if key not found)
	
	path -> key, but special format available (e.g. name.22.age, supports dict+list)
	sep(default:'.') -> Separates the path with sep
	default(default:None) -> returned when path not founded
	"""
	data = _load_latest_stored_cache()
	if data is None:
		raise CacheFileNotFoundError("No latest cache file was found!")
	for key in path.split(sep):
		if isinstance(data, dict):
			if key in data:
				data = data[key]
			else:
				return default
		elif isinstance(data, list):
			if key.isdigit():
				index = int(key)
				if 0 <= index < len(data):
					data = data[index]
				else:
					return default
			else:
				return default
		else:
			return default
	return data

